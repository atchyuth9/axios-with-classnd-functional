import React, { useState } from "react";

const Fun = () => {
  const [count, setCount] = useState(0);
  inc = () => {
    setTimeout(() => setCount(count + 1), 1000);
  };
  dec = () => {
    setTimeout(() => setCount(count - 1), 1000);
  };
  return (
    <div>
      count:{count}
      <br />
      <div>
        <button type="button" onClick={inc}>
          +
        </button>
        <button type="button" onClick={dec}>
          -
        </button>
      </div>
    </div>
  );
};

export default Fun;
