import React, { useState } from "react";

const Form = () => {
  const [data, setData] = useState({
    Name: "",
    Pwd: ""
  });
  const { Name, Pwd } = data;
  const change = (e) => {
    setData({ ...data, [e.target.Name]: [e.target.value] });
  };
  const Submit = (e) => {
    e.preventDefault();
    console.log(data);
  };

  return (
    <div>
      <form onSubmit={Submit}>
        <input
          type="text"
          placeholder="enter name"
          name="Name"
          value={Name}
          onChange={change}
        />
        <br />
        <input
          type="password"
          placeholder="enter pwd"
          name="Pwd"
          value={Pwd}
          onChange={change}
        />
        <br />
        <input type="submit" />
        <br />
      </form>
    </div>
  );
};

export default Form;
