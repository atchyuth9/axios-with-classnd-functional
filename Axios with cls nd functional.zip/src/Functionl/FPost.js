import axios from "axios";
import React, { useState, useEffect } from "react";
let FPost = () => {
  const [name, setName] = useState("");
  {
    /*const [postdata, setpostData] = useState("");
  const username = (event) => {
    setName(event.target.value);
  };
  async function postnam() {
    const { data } = await axios.post(
      "https://jsonplaceholder.typicode.com/users",
      name
    );
    setpostData(data);
  }
  useEffect(() => {
    postnam();
  }, []);
*/
  }
  const username = (event) => {
    setName(event.target.value);
  };
  const handleform = (e) => {
    e.preventDefault();
    axios
      .post("https://jsonplaceholder.typicode.com/users", name)
      .then((response) => {
        console.log(response);
        setName(response.data);
      })
      // postnam();
      .catch((error) => {
        console.log("notfound", error);
      });
  };
  return (
    <div>
      <form onSubmit={handleform}>
        <div>
          <label>
            Postdata :
            <input
              type="text"
              onChange={username}
              name={name}
              placeholder="enter name"
            />
            <br />
            <br />
            submit : <input type="submit" value="submit" />
          </label>
        </div>
      </form>
    </div>
  );
};

export default FPost;
