import React from "react";

class Api extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: []
    };
  }
  Click() {
    var name: "achyu";
    var myArray = this.state.data.slice();
    myArray.push(name),
      this.setState({
        data: myArray
      });
  }
  render() {
    return (
      <div>
        <button onClick={this.Click}>+</button>
      </div>
    );
  }
}

export default Api;
